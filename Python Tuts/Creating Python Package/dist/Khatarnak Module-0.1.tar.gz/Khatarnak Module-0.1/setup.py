from setuptools import setup, find_packages
setup(name='Khatarnak Module', version='0.1', description='Returns a number entered by the user',
      long_description='I Krishanu Karmakar have created this Khatarnak Module to return the number\
        entered by the user or given to the function as an arguement',
        author='Mr. Krishanu Karmakar',
        author_email='krishanukarmakar.kk94@gmail.com',
        packages=['mypackage'],
        install_requires=['numpy']
    )