def function(number):
    return f'You have entered number {number}'